package com.scrapms.devicebridge.service;

import com.scrapms.devicebridge.model.CameraConfig;
import javafx.scene.image.Image;
import okhttp3.*;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.Java2DFrameConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Service for camera streaming and snapshot capture
 */
public class CameraService {
    
    private static final Logger logger = LoggerFactory.getLogger(CameraService.class);
    
    private final Map<Integer, FFmpegFrameGrabber> grabbers = new ConcurrentHashMap<>();
    private final Map<Integer, Boolean> activeStreams = new ConcurrentHashMap<>();
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private final OkHttpClient httpClient = new OkHttpClient();
    
    /**
     * Capture snapshot from camera
     */
    public void captureSnapshot(int cameraId, CameraConfig config, Consumer<CaptureResult> callback) {
        executor.submit(() -> {
            try {
                String url = config.getEffectiveUrl();
                
                if (url == null || url.trim().isEmpty()) {
                    callback.accept(new CaptureResult(false, "No camera URL configured", null));
                    return;
                }
                
                // Check if HTTP or RTSP
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    captureHttpSnapshot(cameraId, config, callback);
                } else if (url.startsWith("rtsp://")) {
                    captureRtspSnapshot(cameraId, config, callback);
                } else {
                    callback.accept(new CaptureResult(false, "Unsupported URL protocol", null));
                }
                
            } catch (Exception e) {
                logger.error("Error capturing snapshot from camera {}", cameraId, e);
                callback.accept(new CaptureResult(false, e.getMessage(), null));
            }
        });
    }
    
    /**
     * Capture snapshot from HTTP stream
     */
    private void captureHttpSnapshot(int cameraId, CameraConfig config, Consumer<CaptureResult> callback) {
        try {
            String url = config.getEffectiveUrl();
            logger.info("[HTTP] Capturing snapshot from camera {}: {}", cameraId, url);
            
            Request.Builder requestBuilder = new Request.Builder().url(url);
            
            // Add basic auth if credentials provided
            if (config.getUsername() != null && config.getPassword() != null) {
                String credentials = Credentials.basic(config.getUsername(), config.getPassword());
                requestBuilder.addHeader("Authorization", credentials);
            }
            
            Request request = requestBuilder.build();
            
            try (Response response = httpClient.newCall(request).execute()) {
                if (response.isSuccessful() && response.body() != null) {
                    byte[] imageBytes = response.body().bytes();
                    String base64 = Base64.getEncoder().encodeToString(imageBytes);
                    String dataUrl = "data:image/jpeg;base64," + base64;
                    
                    logger.info("[HTTP] Snapshot captured successfully from camera {}", cameraId);
                    callback.accept(new CaptureResult(true, null, dataUrl));
                } else {
                    logger.error("[HTTP] Failed to capture snapshot: {}", response.code());
                    callback.accept(new CaptureResult(false, "HTTP " + response.code(), null));
                }
            }
            
        } catch (Exception e) {
            logger.error("[HTTP] Error capturing snapshot", e);
            callback.accept(new CaptureResult(false, e.getMessage(), null));
        }
    }
    
    /**
     * Capture snapshot from RTSP stream
     */
    private void captureRtspSnapshot(int cameraId, CameraConfig config, Consumer<CaptureResult> callback) {
        FFmpegFrameGrabber grabber = null;
        try {
            String url = buildRtspUrl(config);
            logger.info("[RTSP] Capturing snapshot from camera {}: {}", cameraId, config.getEffectiveUrl());
            
            grabber = new FFmpegFrameGrabber(url);
            grabber.setOption("rtsp_transport", config.getTransport());
            grabber.setOption("stimeout", String.valueOf(config.getTimeout() * 1000000));
            grabber.start();
            
            // Grab first frame
            Frame frame = grabber.grab();
            if (frame != null && frame.image != null) {
                // Convert frame to BufferedImage
                Java2DFrameConverter converter = new Java2DFrameConverter();
                BufferedImage bufferedImage = converter.convert(frame);
                
                // Convert to base64
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ImageIO.write(bufferedImage, "jpg", baos);
                byte[] imageBytes = baos.toByteArray();
                String base64 = Base64.getEncoder().encodeToString(imageBytes);
                String dataUrl = "data:image/jpeg;base64," + base64;
                
                logger.info("[RTSP] Snapshot captured successfully from camera {}", cameraId);
                callback.accept(new CaptureResult(true, null, dataUrl));
            } else {
                logger.error("[RTSP] No frame captured from camera {}", cameraId);
                callback.accept(new CaptureResult(false, "No frame available", null));
            }
            
            grabber.stop();
            
        } catch (Exception e) {
            logger.error("[RTSP] Error capturing snapshot", e);
            callback.accept(new CaptureResult(false, e.getMessage(), null));
        } finally {
            if (grabber != null) {
                try {
                    grabber.release();
                } catch (Exception e) {
                    logger.warn("Error releasing grabber", e);
                }
            }
        }
    }
    
    /**
     * Start live preview
     */
    public void startLivePreview(int cameraId, CameraConfig config, 
                                Consumer<Image> onFrame, int fps) {
        stopLivePreview(cameraId);
        
        activeStreams.put(cameraId, true);
        
        executor.submit(() -> {
            FFmpegFrameGrabber grabber = null;
            try {
                String url = config.getEffectiveUrl();
                
                if (url.startsWith("rtsp://")) {
                    url = buildRtspUrl(config);
                    grabber = new FFmpegFrameGrabber(url);
                    grabber.setOption("rtsp_transport", config.getTransport());
                    grabber.setOption("stimeout", String.valueOf(config.getTimeout() * 1000000));
                    grabber.start();
                    
                    grabbers.put(cameraId, grabber);
                    
                    Java2DFrameConverter converter = new Java2DFrameConverter();
                    long frameDelay = 1000 / fps;
                    
                    while (activeStreams.getOrDefault(cameraId, false)) {
                        Frame frame = grabber.grab();
                        if (frame != null && frame.image != null) {
                            BufferedImage bufferedImage = converter.convert(frame);
                            
                            // Convert to JavaFX Image
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            ImageIO.write(bufferedImage, "jpg", baos);
                            Image fxImage = new Image(new ByteArrayInputStream(baos.toByteArray()));
                            
                            onFrame.accept(fxImage);
                        }
                        
                        Thread.sleep(frameDelay);
                    }
                    
                    grabber.stop();
                }
                
            } catch (Exception e) {
                logger.error("Error in live preview for camera {}", cameraId, e);
            } finally {
                if (grabber != null) {
                    try {
                        grabber.release();
                    } catch (Exception e) {
                        logger.warn("Error releasing grabber", e);
                    }
                }
                grabbers.remove(cameraId);
            }
        });
    }
    
    /**
     * Stop live preview
     */
    public void stopLivePreview(int cameraId) {
        activeStreams.put(cameraId, false);
        FFmpegFrameGrabber grabber = grabbers.remove(cameraId);
        if (grabber != null) {
            try {
                grabber.stop();
                grabber.release();
                logger.info("Stopped live preview for camera {}", cameraId);
            } catch (Exception e) {
                logger.warn("Error stopping grabber", e);
            }
        }
    }
    
    /**
     * Stop all previews
     */
    public void stopAllPreviews() {
        new java.util.ArrayList<>(grabbers.keySet()).forEach(this::stopLivePreview);
    }
    
    /**
     * Build RTSP URL with credentials
     */
    private String buildRtspUrl(CameraConfig config) {
        String url = config.getRtspUrl();
        
        if (config.getUsername() != null && config.getPassword() != null) {
            try {
                if (url.startsWith("rtsp://")) {
                    return String.format("rtsp://%s:%s@%s", 
                            config.getUsername(), 
                            config.getPassword(), 
                            url.substring(7));
                }
            } catch (Exception e) {
                logger.warn("Error building RTSP URL with credentials", e);
            }
        }
        
        return url;
    }
    
    /**
     * Shutdown service
     */
    public void shutdown() {
        stopAllPreviews();
        executor.shutdown();
    }
    
    /**
     * Capture Result
     */
    public static class CaptureResult {
        private final boolean success;
        private final String error;
        private final String imageData;
        
        public CaptureResult(boolean success, String error, String imageData) {
            this.success = success;
            this.error = error;
            this.imageData = imageData;
        }
        
        public boolean isSuccess() { return success; }
        public String getError() { return error; }
        public String getImageData() { return imageData; }
    }
}
