package com.scrapms.devicebridge.service;

import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;
import com.scrapms.devicebridge.model.WeighbridgeConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Service for serial port communication with weighbridges
 */
public class SerialPortService {
    
    private static final Logger logger = LoggerFactory.getLogger(SerialPortService.class);
    
    private final Map<Integer, SerialPort> ports = new ConcurrentHashMap<>();
    private final Map<Integer, StringBuilder> buffers = new ConcurrentHashMap<>();
    private final Map<Integer, WeighbridgeConfig> configs = new ConcurrentHashMap<>();
    private final Map<Integer, List<Double>> lastReadings = new ConcurrentHashMap<>();
    private final Map<Integer, Consumer<WeightReading>> callbacks = new ConcurrentHashMap<>();
    
    /**
     * Connect to weighbridge serial port
     */
    public ConnectionResult connect(int weighbridgeId, WeighbridgeConfig config, 
                                   Consumer<WeightReading> onReading) {
        try {
            // Disconnect if already connected
            disconnect(weighbridgeId);
            
            logger.info("Connecting to {} for weighbridge {}", config.getSerialPort(), weighbridgeId);
            
            SerialPort port = SerialPort.getCommPort(config.getSerialPort());
            port.setBaudRate(config.getBaudRate());
            port.setNumDataBits(config.getDataBits());
            port.setNumStopBits(config.getStopBits());
            port.setParity(getParity(config.getParity()));
            
            if (port.openPort()) {
                logger.info("Connected to {}", config.getSerialPort());
                
                ports.put(weighbridgeId, port);
                buffers.put(weighbridgeId, new StringBuilder());
                configs.put(weighbridgeId, config);
                lastReadings.put(weighbridgeId, new ArrayList<>());
                callbacks.put(weighbridgeId, onReading);
                
                // Start listening for data
                port.addDataListener(new SerialPortDataListener() {
                    @Override
                    public int getListeningEvents() {
                        return SerialPort.LISTENING_EVENT_DATA_AVAILABLE;
                    }
                    
                    @Override
                    public void serialEvent(SerialPortEvent event) {
                        if (event.getEventType() == SerialPort.LISTENING_EVENT_DATA_AVAILABLE) {
                            byte[] buffer = new byte[port.bytesAvailable()];
                            port.readBytes(buffer, buffer.length);
                            handleData(weighbridgeId, new String(buffer, StandardCharsets.UTF_8));
                        }
                    }
                });
                
                return new ConnectionResult(true, null);
            } else {
                logger.error("Failed to open port: {}", config.getSerialPort());
                return new ConnectionResult(false, "Failed to open port");
            }
            
        } catch (Exception e) {
            logger.error("Error connecting to serial port", e);
            return new ConnectionResult(false, e.getMessage());
        }
    }
    
    /**
     * Disconnect from weighbridge
     */
    public void disconnect(int weighbridgeId) {
        SerialPort port = ports.remove(weighbridgeId);
        if (port != null && port.isOpen()) {
            port.closePort();
            logger.info("Disconnected weighbridge {}", weighbridgeId);
        }
        buffers.remove(weighbridgeId);
        configs.remove(weighbridgeId);
        lastReadings.remove(weighbridgeId);
        callbacks.remove(weighbridgeId);
    }
    
    /**
     * Disconnect all weighbridges
     */
    public void disconnectAll() {
        new ArrayList<>(ports.keySet()).forEach(this::disconnect);
    }
    
    /**
     * Check if weighbridge is connected
     */
    public boolean isConnected(int weighbridgeId) {
        SerialPort port = ports.get(weighbridgeId);
        return port != null && port.isOpen();
    }
    
    /**
     * Request a weight reading
     */
    public WeightReading requestReading(int weighbridgeId) {
        List<Double> readings = lastReadings.get(weighbridgeId);
        WeighbridgeConfig config = configs.get(weighbridgeId);
        
        if (readings != null && !readings.isEmpty() && config != null) {
            double latestWeight = readings.get(readings.size() - 1);
            boolean isStable = checkStability(readings, config);
            
            return new WeightReading(
                latestWeight,
                config.getWeightUnit(),
                isStable,
                String.format("%.2f %s", latestWeight, config.getWeightUnit()),
                LocalDateTime.now()
            );
        }
        
        return null;
    }
    
    /**
     * Handle incoming data from serial port
     */
    private void handleData(int weighbridgeId, String data) {
        WeighbridgeConfig config = configs.get(weighbridgeId);
        if (config == null) return;
        
        StringBuilder buffer = buffers.get(weighbridgeId);
        buffer.append(data);
        
        // Try to parse weight
        WeightReading reading = parseWeight(buffer.toString(), config);
        
        if (reading != null) {
            // Clear buffer after successful parse
            buffer.setLength(0);
            
            // Update last readings
            List<Double> readings = lastReadings.get(weighbridgeId);
            readings.add(reading.getWeight());
            
            // Keep only last N readings
            if (readings.size() > config.getStableReadings()) {
                readings.remove(0);
            }
            
            // Check stability
            boolean isStable = checkStability(readings, config);
            reading = new WeightReading(
                reading.getWeight(),
                reading.getUnit(),
                isStable,
                reading.getRawData(),
                reading.getTimestamp()
            );
            
            // Callback
            Consumer<WeightReading> callback = callbacks.get(weighbridgeId);
            if (callback != null) {
                callback.accept(reading);
            }
        } else {
            // Limit buffer size
            if (buffer.length() > 1024) {
                buffer.delete(0, buffer.length() - 512);
            }
        }
    }
    
    /**
     * Parse weight from buffer
     */
    private WeightReading parseWeight(String buffer, WeighbridgeConfig config) {
        try {
            String rawData = buffer;
            
            // Extract data between markers if defined
            if (config.getWeightStartMarker() != null && config.getWeightEndMarker() != null) {
                int startIdx = buffer.indexOf(config.getWeightStartMarker());
                int endIdx = buffer.indexOf(config.getWeightEndMarker(), 
                        startIdx + config.getWeightStartMarker().length());
                
                if (startIdx == -1 || endIdx == -1) {
                    return null;
                }
                
                rawData = buffer.substring(startIdx + config.getWeightStartMarker().length(), endIdx);
            }
            
            // Extract weight using regex
            Double weightValue = null;
            
            if (config.getWeightRegex() != null && !config.getWeightRegex().isEmpty()) {
                Pattern pattern = Pattern.compile(config.getWeightRegex());
                Matcher matcher = pattern.matcher(rawData);
                if (matcher.find()) {
                    String match = matcher.groupCount() > 0 ? matcher.group(1) : matcher.group(0);
                    weightValue = Double.parseDouble(match);
                }
            } else {
                // Default: find any number
                Pattern pattern = Pattern.compile("[-+]?\\d*\\.?\\d+");
                Matcher matcher = pattern.matcher(rawData);
                if (matcher.find()) {
                    weightValue = Double.parseDouble(matcher.group(0));
                }
            }
            
            if (weightValue == null) {
                return null;
            }
            
            // Apply multiplier
            weightValue *= config.getWeightMultiplier();
            
            return new WeightReading(
                weightValue,
                config.getWeightUnit(),
                false, // Stability will be checked later
                rawData.trim(),
                LocalDateTime.now()
            );
            
        } catch (Exception e) {
            logger.debug("Error parsing weight: {}", e.getMessage());
            return null;
        }
    }
    
    /**
     * Check if readings are stable
     */
    private boolean checkStability(List<Double> readings, WeighbridgeConfig config) {
        if (readings.size() < config.getStableReadings()) {
            return false;
        }
        
        List<Double> recentReadings = readings.subList(
                Math.max(0, readings.size() - config.getStableReadings()), 
                readings.size()
        );
        
        double max = Collections.max(recentReadings);
        double min = Collections.min(recentReadings);
        double variance = max - min;
        
        return variance <= config.getStabilityThreshold();
    }
    
    /**
     * Convert parity string to SerialPort constant
     */
    private int getParity(String parity) {
        switch (parity.toLowerCase()) {
            case "even": return SerialPort.EVEN_PARITY;
            case "odd": return SerialPort.ODD_PARITY;
            case "mark": return SerialPort.MARK_PARITY;
            case "space": return SerialPort.SPACE_PARITY;
            default: return SerialPort.NO_PARITY;
        }
    }
    
    /**
     * List available serial ports
     */
    public static List<String> listPorts() {
        List<String> portNames = new ArrayList<>();
        SerialPort[] ports = SerialPort.getCommPorts();
        for (SerialPort port : ports) {
            portNames.add(port.getSystemPortName());
        }
        return portNames;
    }
    
    /**
     * Connection Result
     */
    public static class ConnectionResult {
        private final boolean success;
        private final String error;
        
        public ConnectionResult(boolean success, String error) {
            this.success = success;
            this.error = error;
        }
        
        public boolean isSuccess() { return success; }
        public String getError() { return error; }
    }
    
    /**
     * Weight Reading
     */
    public static class WeightReading {
        private final double weight;
        private final String unit;
        private final boolean isStable;
        private final String rawData;
        private final LocalDateTime timestamp;
        
        public WeightReading(double weight, String unit, boolean isStable, 
                           String rawData, LocalDateTime timestamp) {
            this.weight = weight;
            this.unit = unit;
            this.isStable = isStable;
            this.rawData = rawData;
            this.timestamp = timestamp;
        }
        
        public double getWeight() { return weight; }
        public String getUnit() { return unit; }
        public boolean isStable() { return isStable; }
        public String getRawData() { return rawData; }
        public LocalDateTime getTimestamp() { return timestamp; }
    }
}
